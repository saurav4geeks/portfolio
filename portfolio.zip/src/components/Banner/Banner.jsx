import React from "react";
import bannerImg from "../../assets/images/portfolio_banner_crop.png";
import "./Banner.css";

function Banner() {
  return (
    <div className="banner-wrapper">
      <img className="img-fluid" src={bannerImg} alt="Banner Image" />
      <div className="social-links d-flex align-items-center">
        <a className="mx-2 link" href="#">
          LN
        </a>
        <a className="mx-2 link" href="#">
          GH
        </a>
      </div>
      <div className="banner-content">
        <h6>LET'S WORK TOGETHER</h6>
        <p>I’m available at</p>
        <ul className="list-unstyled">
          <li>
            <a className="link" href="mailto:sauravsuman5980@gmail.com">
              sauravsuman5980@gmail.com
            </a>
          </li>
          <li>
            <a className="link" href="tel:+9155962770">
              (+91) 9155962770
            </a>
          </li>
        </ul>
      </div>
    </div>
  );
}

export default Banner;
